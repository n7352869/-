const API_BASE = '/api';

let currentTab = 'all';
let currentCategory = 'all';
let currentIdeaId = null;
let ideas = [];

// 初始化
document.addEventListener('DOMContentLoaded', () => {
    initCategories();
    initTabs();
    initForm();
    loadIdeas();
});

// 分类切换
function initCategories() {
    document.querySelectorAll('.category-btn').forEach(btn => {
        btn.addEventListener('click', () => {
            document.querySelectorAll('.category-btn').forEach(b => b.classList.remove('active'));
            btn.classList.add('active');
            currentCategory = btn.dataset.category;
            loadIdeas();
        });
    });
}

// 标签页切换
function initTabs() {
    document.querySelectorAll('.tab-btn').forEach(btn => {
        btn.addEventListener('click', () => {
            document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
            btn.classList.add('active');
            currentTab = btn.dataset.tab;
            loadIdeas();
        });
    });
}

// 发布表单
function initForm() {
    document.getElementById('ideaForm').addEventListener('submit', async (e) => {
        e.preventDefault();
        
        const title = document.getElementById('ideaTitle').value.trim();
        const content = document.getElementById('ideaContent').value.trim();
        const author = document.getElementById('ideaAuthor').value.trim();
        const category = document.getElementById('ideaCategory').value;
        
        if (!title || !content) {
            alert('请填写标题和内容');
            return;
        }
        
        try {
            const response = await fetch(`${API_BASE}/ideas`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({ title, content, author, category })
            });
            
            const data = await response.json();
            
            if (response.ok) {
                alert('发布成功！');
                document.getElementById('ideaForm').reset();
                loadIdeas();
            } else {
                alert('发布失败：' + data.error);
            }
        } catch (error) {
            alert('发布失败：' + error.message);
        }
    });
}

// 加载想法列表
async function loadIdeas() {
    const container = document.getElementById('ideasContainer');
    const loading = document.getElementById('loading');
    const emptyState = document.getElementById('emptyState');
    
    container.innerHTML = '';
    loading.style.display = 'block';
    emptyState.style.display = 'none';
    
    try {
        let url = `${API_BASE}/ideas`;
        
        // 添加分类参数
        const params = new URLSearchParams();
        if (currentCategory && currentCategory !== 'all') {
            params.append('category', currentCategory);
        }
        
        if (currentTab === 'daily') {
            url = `${API_BASE}/ideas/daily-ranking`;
            if (currentCategory && currentCategory !== 'all') {
                params.append('category', currentCategory);
            }
        } else if (currentTab === 'latest') {
            params.append('sort', 'latest');
        } else {
            params.append('sort', 'hot');
        }
        
        if (params.toString()) {
            url += '?' + params.toString();
        }
        
        const response = await fetch(url);
        const data = await response.json();
        
        loading.style.display = 'none';
        
        if (data.length === 0) {
            emptyState.style.display = 'block';
            return;
        }
        
        ideas = data;
        data.forEach((idea, index) => {
            const card = createIdeaCard(idea, index + 1);
            container.appendChild(card);
        });
        
        // 加载点赞状态
        data.forEach((idea, index) => {
            checkLikeStatus(idea.id, index);
        });
    } catch (error) {
        loading.style.display = 'none';
        container.innerHTML = `<div class="error">加载失败：${error.message}</div>`;
    }
}

// 创建想法卡片
function createIdeaCard(idea, rank) {
    const card = document.createElement('div');
    card.className = 'idea-card';
    card.dataset.id = idea.id;
    
    const hotScore = (idea.likes_count || idea.likes || 0) * 2 + (idea.comments_count || 0);
    const rankBadge = currentTab === 'daily' && rank <= 3 
        ? `<span class="idea-rank">🔥 第${rank}名</span>` 
        : '';
    const categoryBadge = idea.category 
        ? `<span class="idea-category">${escapeHtml(idea.category)}</span>` 
        : '';
    
    card.innerHTML = `
        <div class="idea-header">
            <div class="idea-title">${escapeHtml(idea.title)}</div>
            ${rankBadge}
        </div>
        ${categoryBadge}
        <div class="idea-content">${escapeHtml(idea.content)}</div>
        <div class="idea-meta">
            <span>👤 ${escapeHtml(idea.author || '匿名用户')}</span>
            <span>🕒 ${formatTime(idea.created_at)}</span>
        </div>
        <div class="idea-actions">
            <button class="action-btn like-btn" data-id="${idea.id}">
                <span class="like-icon">${currentTab === 'daily' ? '🔥' : '👍'}</span>
                <span class="like-count">${idea.likes_count || idea.likes || 0}</span>
            </button>
            <button class="action-btn comment-btn" data-id="${idea.id}">
                💬 评论 <span class="comment-count">${idea.comments_count || 0}</span>
            </button>
        </div>
    `;
    
    // 点赞按钮事件
    card.querySelector('.like-btn').addEventListener('click', () => toggleLike(idea.id));
    
    // 评论按钮事件
    card.querySelector('.comment-btn').addEventListener('click', () => openCommentModal(idea.id));
    
    return card;
}

// 切换点赞
async function toggleLike(ideaId) {
    try {
        const response = await fetch(`${API_BASE}/ideas/${ideaId}/like`, {
            method: 'POST'
        });
        
        const data = await response.json();
        
        if (response.ok) {
            const btn = document.querySelector(`.like-btn[data-id="${ideaId}"]`);
            const countSpan = btn.querySelector('.like-count');
            
            countSpan.textContent = data.likes;
            
            if (data.liked) {
                btn.classList.add('liked');
            } else {
                btn.classList.remove('liked');
            }
            
            // 如果是今日热门，重新加载以更新排名
            if (currentTab === 'daily') {
                setTimeout(() => loadIdeas(), 500);
            }
        }
    } catch (error) {
        alert('操作失败：' + error.message);
    }
}

// 检查点赞状态
async function checkLikeStatus(ideaId, index) {
    try {
        const response = await fetch(`${API_BASE}/ideas/${ideaId}/like-status`);
        const data = await response.json();
        
        if (data.liked) {
            const btn = document.querySelector(`.like-btn[data-id="${ideaId}"]`);
            if (btn) {
                btn.classList.add('liked');
            }
        }
    } catch (error) {
        // 忽略错误
    }
}

// 打开评论模态框
async function openCommentModal(ideaId) {
    currentIdeaId = ideaId;
    const modal = document.getElementById('commentModal');
    modal.classList.add('show');
    
    await loadComments(ideaId);
    
    // 重置表单
    document.getElementById('commentForm').reset();
    document.getElementById('commentForm').onsubmit = async (e) => {
        e.preventDefault();
        await submitComment(ideaId);
    };
}

// 加载评论
async function loadComments(ideaId) {
    const commentList = document.getElementById('commentList');
    commentList.innerHTML = '<div class="loading">加载中...</div>';
    
    try {
        const response = await fetch(`${API_BASE}/ideas/${ideaId}/comments`);
        const comments = await response.json();
        
        if (comments.length === 0) {
            commentList.innerHTML = '<p style="text-align: center; color: #999;">还没有评论，快来第一个评论吧！</p>';
            return;
        }
        
        commentList.innerHTML = comments.map(comment => `
            <div class="comment-item">
                <div class="comment-header">
                    <span class="comment-author">${escapeHtml(comment.author || '匿名用户')}</span>
                    <span class="comment-time">${formatTime(comment.created_at)}</span>
                </div>
                <div class="comment-content">${escapeHtml(comment.content)}</div>
            </div>
        `).join('');
    } catch (error) {
        commentList.innerHTML = `<div class="error">加载失败：${error.message}</div>`;
    }
}

// 提交评论
async function submitComment(ideaId) {
    const content = document.getElementById('commentContent').value.trim();
    const author = document.getElementById('commentAuthor').value.trim();
    
    if (!content) {
        alert('请输入评论内容');
        return;
    }
    
    try {
        const response = await fetch(`${API_BASE}/ideas/${ideaId}/comments`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ content, author })
        });
        
        const data = await response.json();
        
        if (response.ok) {
            document.getElementById('commentContent').value = '';
            await loadComments(ideaId);
            loadIdeas(); // 刷新列表以更新评论数
        } else {
            alert('评论失败：' + data.error);
        }
    } catch (error) {
        alert('评论失败：' + error.message);
    }
}

// 关闭模态框
document.querySelector('.close').addEventListener('click', () => {
    document.getElementById('commentModal').classList.remove('show');
});

document.getElementById('commentModal').addEventListener('click', (e) => {
    if (e.target.id === 'commentModal') {
        document.getElementById('commentModal').classList.remove('show');
    }
});

// 工具函数
function escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

function formatTime(timeString) {
    const date = new Date(timeString);
    const now = new Date();
    const diff = now - date;
    
    if (diff < 60000) {
        return '刚刚';
    } else if (diff < 3600000) {
        return `${Math.floor(diff / 60000)}分钟前`;
    } else if (diff < 86400000) {
        return `${Math.floor(diff / 3600000)}小时前`;
    } else if (diff < 604800000) {
        return `${Math.floor(diff / 86400000)}天前`;
    } else {
        return date.toLocaleDateString('zh-CN');
    }
}

