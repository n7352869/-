# 📱 Android APP 开发指南

## 项目说明

这是一个基于 WebView 的 Android 应用，将"我有一个想法"网站打包成原生 Android APP。

## 开发环境要求

1. **Android Studio** (推荐最新版本)
   - 下载地址：https://developer.android.com/studio
   
2. **JDK 8 或更高版本**
   - Android Studio 自带 JDK，无需单独安装

3. **Android SDK**
   - 通过 Android Studio 的 SDK Manager 安装
   - 最低支持 Android 5.0 (API 21)
   - 目标版本 Android 14 (API 34)

## 项目结构

```
android/
├── app/
│   ├── src/
│   │   └── main/
│   │       ├── java/com/woyouyigexiangfa/app/
│   │       │   └── MainActivity.java      # 主Activity
│   │       ├── res/
│   │       │   ├── layout/
│   │       │   │   └── activity_main.xml  # 主界面布局
│   │       │   ├── values/
│   │       │   │   ├── strings.xml        # 字符串资源
│   │       │   │   └── styles.xml         # 样式资源
│   │       │   └── mipmap/               # 应用图标
│   │       └── AndroidManifest.xml        # 应用清单文件
│   ├── build.gradle                       # 应用级构建配置
│   └── proguard-rules.pro                 # 代码混淆规则
├── build.gradle                           # 项目级构建配置
├── settings.gradle                        # 项目设置
└── gradle.properties                      # Gradle属性配置
```

## 配置步骤

### 1. 配置服务器地址

打开 `app/src/main/java/com/woyouyigexiangfa/app/ServerConfig.java`，修改 `SERVER_URL` 变量：

```java
// 开发环境：使用电脑IP地址（确保手机和电脑在同一WiFi）
public static final String SERVER_URL = "http://192.168.1.100:3000";

// 如果使用Android模拟器，使用：
// private static final String SERVER_URL = "http://10.0.2.2:3000";

// 生产环境：替换为实际部署的服务器地址
// private static final String SERVER_URL = "https://your-server.com";
```

**获取电脑IP地址：**
- Windows: 打开命令提示符，输入 `ipconfig`，查找 IPv4 地址
- Mac/Linux: 打开终端，输入 `ifconfig` 或 `ip addr`

### 2. 配置 Android SDK 路径

创建 `local.properties` 文件（如果 Android Studio 没有自动创建）：

```properties
sdk.dir=C\\Users\\YourUsername\\AppData\\Local\\Android\\Sdk
```

将路径替换为你的实际 Android SDK 路径。

### 3. 启动后端服务器

在项目根目录运行：

```bash
# Windows
一键部署.bat

# Mac/Linux
npm install && npm start
```

确保服务器运行在 `http://localhost:3000`

## 构建和运行

### 方式一：使用 Android Studio（推荐）

1. 打开 Android Studio
2. 选择 "Open an Existing Project"
3. 选择 `android` 文件夹
4. 等待 Gradle 同步完成
5. 连接 Android 设备或启动模拟器
6. 点击运行按钮（绿色三角形）或按 `Shift+F10`

### 方式二：使用命令行

```bash
# 进入 android 目录
cd android

# 构建 Debug APK
./gradlew assembleDebug

# 构建 Release APK
./gradlew assembleRelease

# 安装到连接的设备
./gradlew installDebug
```

**Windows 用户使用：**
```bash
gradlew.bat assembleDebug
gradlew.bat installDebug
```

生成的 APK 文件位置：
- Debug: `app/build/outputs/apk/debug/app-debug.apk`
- Release: `app/build/outputs/apk/release/app-release.apk`

## 测试

### 使用真实设备

1. 在手机上启用"开发者选项"和"USB调试"
2. 用 USB 连接手机到电脑
3. 在 Android Studio 中选择设备并运行

### 使用模拟器

1. 在 Android Studio 中创建虚拟设备（AVD）
2. 启动模拟器
3. 修改 `MainActivity.java` 中的 `SERVER_URL` 为 `http://10.0.2.2:3000`
4. 运行应用

### 网络配置

**重要：** 确保手机和电脑在同一 WiFi 网络下，并且：
- 电脑防火墙允许端口 3000 的入站连接
- 手机可以访问电脑的 IP 地址

## 打包发布

### 1. 生成签名密钥

```bash
keytool -genkey -v -keystore my-release-key.jks -keyalg RSA -keysize 2048 -validity 10000 -alias my-key-alias
```

### 2. 配置签名

在 `app/build.gradle` 中添加：

```gradle
android {
    ...
    signingConfigs {
        release {
            storeFile file('my-release-key.jks')
            storePassword 'your-store-password'
            keyAlias 'my-key-alias'
            keyPassword 'your-key-password'
        }
    }
    buildTypes {
        release {
            signingConfig signingConfigs.release
            ...
        }
    }
}
```

### 3. 构建发布版

```bash
./gradlew assembleRelease
```

## 功能特性

- ✅ 完整的 WebView 支持
- ✅ JavaScript 启用
- ✅ 本地存储支持
- ✅ 进度条显示
- ✅ 返回键支持（返回上一页）
- ✅ 响应式布局
- ✅ 网络状态检测

## 常见问题

### 1. 无法连接到服务器

**问题：** APP 显示无法加载页面

**解决方案：**
- 检查服务器是否正在运行
- 检查手机和电脑是否在同一 WiFi 网络
- 检查电脑防火墙设置
- 确认 IP 地址是否正确
- 尝试在手机浏览器中直接访问服务器地址

### 2. Gradle 同步失败

**问题：** Android Studio 提示 Gradle 同步失败

**解决方案：**
- 检查网络连接（需要下载依赖）
- 使用国内镜像（在 `build.gradle` 中添加镜像源）
- 更新 Android Studio 和 Gradle 版本

### 3. 应用崩溃

**问题：** 应用启动后立即崩溃

**解决方案：**
- 检查 `AndroidManifest.xml` 配置
- 查看 Logcat 日志获取详细错误信息
- 确认最低 SDK 版本是否支持

### 4. 网络请求被阻止

**问题：** 无法发送 API 请求

**解决方案：**
- 确认 `AndroidManifest.xml` 中有网络权限
- 检查 `usesCleartextTraffic` 设置（HTTP 需要设置为 true）

## 部署到生产环境

1. **部署后端服务器**
   - 将 Node.js 服务器部署到云服务器（如阿里云、腾讯云）
   - 或使用 Heroku、Vercel 等平台

2. **修改服务器地址**
   - 在 `MainActivity.java` 中更新 `SERVER_URL` 为生产环境地址

3. **构建发布版 APK**
   - 按照"打包发布"步骤生成签名 APK

4. **发布应用**
   - 上传到应用商店（如 Google Play、应用宝等）
   - 或直接分发 APK 文件

## 技术支持

如有问题，请查看：
- Android 官方文档：https://developer.android.com/
- WebView 文档：https://developer.android.com/reference/android/webkit/WebView

