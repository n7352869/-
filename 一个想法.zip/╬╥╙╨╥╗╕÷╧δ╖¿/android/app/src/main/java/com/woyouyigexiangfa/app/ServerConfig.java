package com.woyouyigexiangfa.app;

/**
 * 服务器配置类
 * 在这里配置你的服务器地址
 */
public class ServerConfig {
    
    // ============================================
    // 配置说明：
    // ============================================
    // 
    // 1. 开发环境（手机和电脑在同一WiFi）：
    //    使用电脑的IP地址，例如：http://192.168.1.100:3000
    //    获取IP方法：
    //    - Windows: 打开cmd，输入 ipconfig
    //    - Mac/Linux: 打开终端，输入 ifconfig
    //
    // 2. Android模拟器：
    //    使用：http://10.0.2.2:3000
    //
    // 3. 生产环境（已部署的服务器）：
    //    使用实际服务器地址，例如：https://your-server.com
    //
    // ============================================
    
    // 服务器地址 - 请根据实际情况修改
    public static final String SERVER_URL = "http://192.168.1.100:3000";
    
    // 是否启用调试模式
    public static final boolean DEBUG_MODE = true;
}

