# 📱 Android APP 快速开始指南

## 🚀 5分钟快速部署

### 第一步：配置服务器地址

1. 打开文件：`android/app/src/main/java/com/woyouyigexiangfa/app/ServerConfig.java`

2. 修改服务器地址：
   ```java
   public static final String SERVER_URL = "http://你的电脑IP:3000";
   ```

3. 获取电脑IP地址：
   - **Windows**: 打开cmd，输入 `ipconfig`，查找"IPv4 地址"
   - **Mac**: 打开终端，输入 `ifconfig | grep "inet "`
   - **Linux**: 打开终端，输入 `ip addr` 或 `hostname -I`

4. 示例：
   ```java
   // 如果电脑IP是 192.168.1.105
   public static final String SERVER_URL = "http://192.168.1.105:3000";
   
   // 如果使用Android模拟器
   public static final String SERVER_URL = "http://10.0.2.2:3000";
   ```

### 第二步：启动后端服务器

在项目根目录（"我有一个想法"文件夹）：

**Windows:**
```
双击运行"一键部署.bat"
```

**Mac/Linux:**
```bash
npm install && npm start
```

确保看到：`服务器运行在 http://localhost:3000`

### 第三步：测试网络连接

在手机浏览器中访问：`http://你的电脑IP:3000`

如果能正常打开网站，说明网络配置正确 ✅

### 第四步：使用 Android Studio 打开项目

1. 打开 **Android Studio**
2. 选择 **File → Open**
3. 选择 `android` 文件夹
4. 等待 Gradle 同步完成（首次可能需要几分钟）

### 第五步：运行应用

1. **连接设备**：
   - 用USB连接Android手机，并启用"USB调试"
   - 或启动Android模拟器

2. **运行应用**：
   - 点击工具栏的绿色运行按钮 ▶️
   - 或按快捷键 `Shift + F10`

3. **等待安装完成**，应用会自动启动

## 📋 完整项目结构

```
android/
├── app/
│   ├── src/main/
│   │   ├── java/com/woyouyigexiangfa/app/
│   │   │   ├── MainActivity.java      ← 主界面
│   │   │   └── ServerConfig.java     ← 服务器配置（重要！）
│   │   ├── res/
│   │   │   ├── layout/
│   │   │   │   └── activity_main.xml  ← 界面布局
│   │   │   └── values/
│   │   │       ├── strings.xml        ← 应用名称
│   │   │       └── styles.xml         ← 主题样式
│   │   └── AndroidManifest.xml        ← 应用配置
│   └── build.gradle                   ← 依赖配置
├── build.gradle
├── settings.gradle
└── README_ANDROID.md                  ← 详细文档
```

## ⚙️ 常见配置场景

### 场景1：手机和电脑在同一WiFi

```java
// ServerConfig.java
public static final String SERVER_URL = "http://192.168.1.105:3000";
```

**要求：**
- 手机和电脑连接同一WiFi
- 电脑防火墙允许端口3000
- 服务器正在运行

### 场景2：使用Android模拟器

```java
// ServerConfig.java
public static final String SERVER_URL = "http://10.0.2.2:3000";
```

**说明：**
- `10.0.2.2` 是Android模拟器访问电脑localhost的特殊地址
- 不需要修改防火墙设置

### 场景3：使用已部署的服务器

```java
// ServerConfig.java
public static final String SERVER_URL = "https://your-server.com";
```

**说明：**
- 将网站部署到云服务器后
- 使用HTTPS协议更安全

## 🔧 生成APK文件

### 方法一：Android Studio（推荐）

1. **Build → Generate Signed Bundle / APK**
2. 选择 **APK**
3. 创建新的密钥库（首次）或选择已有密钥库
4. 选择 **release** 构建类型
5. 完成构建

**APK位置：** `android/app/build/outputs/apk/release/app-release.apk`

### 方法二：命令行

```bash
cd android
./gradlew assembleRelease
```

**Windows:**
```bash
cd android
gradlew.bat assembleRelease
```

## ❓ 常见问题

### Q1: 应用显示"无法加载页面"

**检查清单：**
- ✅ 服务器是否正在运行？
- ✅ ServerConfig.java 中的IP地址是否正确？
- ✅ 手机和电脑是否在同一WiFi？
- ✅ 电脑防火墙是否允许端口3000？
- ✅ 手机浏览器能否访问服务器地址？

**解决方法：**
1. 在手机浏览器测试：`http://你的IP:3000`
2. 如果浏览器能访问，检查APP中的IP配置
3. 如果浏览器不能访问，检查网络和防火墙

### Q2: Gradle同步失败

**解决方法：**
1. 检查网络连接（需要下载依赖）
2. 使用国内镜像（在 `build.gradle` 中添加）：
   ```gradle
   repositories {
       maven { url 'https://maven.aliyun.com/repository/google' }
       maven { url 'https://maven.aliyun.com/repository/central' }
       google()
       mavenCentral()
   }
   ```
3. 更新Android Studio到最新版本

### Q3: 应用崩溃

**解决方法：**
1. 查看 **Logcat** 获取错误信息
2. 检查 `AndroidManifest.xml` 配置
3. 确认最低SDK版本（需要Android 5.0+）

### Q4: 网络请求被阻止

**解决方法：**
- 确认 `AndroidManifest.xml` 中有网络权限
- 检查 `usesCleartextTraffic` 设置（HTTP需要设为true）

## 📚 更多资源

- **详细文档**: 查看 `android/README_ANDROID.md`
- **配置说明**: 查看 `android/配置说明.txt`
- **Android官方文档**: https://developer.android.com/

## 🎉 完成！

现在你已经可以：
- ✅ 在手机上使用原生APP
- ✅ 发布想法、点赞、评论
- ✅ 查看每日热门排行
- ✅ 生成APK文件进行分发

祝使用愉快！💡

